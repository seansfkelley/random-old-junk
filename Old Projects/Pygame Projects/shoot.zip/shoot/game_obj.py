from aux import *

class Ship(pygame.sprite.Sprite):
    def __init__(self, pos, controls, wep_pattern=PTRN_DEF):
        pygame.sprite.Sprite.__init__(self)
        self.image=images['ship']
        self.rect=self.image.get_rect()
        self.rect.center=tuple(pos)
        self.vert=self.horiz=0
        self.firing=False
        self.interval=0
        self.UP,self.DOWN,self.LEFT,self.RIGHT,self.SHOOT=controls
        self.weapon=Weapon(self, wep_pattern)
        ship_group.add(self)
    def keydown(self, key):
        if key==self.UP:
            self.vert-=1
        elif key==self.DOWN:
            self.vert+=1
        elif key==self.LEFT:
            self.horiz-=1
        elif key==self.RIGHT:
            self.horiz+=1
        elif key==self.SHOOT:
            self.weapon.on()
        else:
            return False
        return True
    def keyup(self, key):
        if key==self.UP:
            self.vert+=1
        elif key==self.DOWN:
            self.vert-=1
        elif key==self.LEFT:
            self.horiz+=1
        elif key==self.RIGHT:
            self.horiz-=1
        elif key==self.SHOOT:
            self.weapon.off()
        else:
            return False
        return True
    def update(self):
        x,y=self.rect.center
        self.rect.center=(x+self.horiz*MOVE_SPEED_HORIZ,y+self.vert*MOVE_SPEED_VERT)
        self.rect.clamp_ip(PLAY_AREA)
        self.weapon.update()
    def die(self):
        self.kill()

class DummyShip:
    def __init__(self, controls):
        self.controls=controls
    def keydown(self, key):
        return key in self.controls
    def keyup(self, key):
        return key in self.controls

class Enemy(pygame.sprite.Sprite):
    def __init__(self, pos, life, img_name, mov_func):
        pygame.sprite.Sprite.__init__(self)
        self.image=images[img_name]
        self.rect=self.image.get_rect()
        self.rect.center=tuple(pos)
        self.origin=Vector(pos)
        self.life=life
        self.movement=mov_func
        self.frames=0
        enemy_group.add(self)
    def update(self):
        self.frames+=1
        self.rect.center=(self.origin+self.movement(self.frames)).to_tuple()
        if not PLAY_AREA.colliderect(self.rect):
            self.kill()
    def damage(self, dmg):
        self.life-=dmg
        if self.life<=0:
            self.kill()

class Shot(pygame.sprite.Sprite):
    def __init__(self, pos, dmg, img_name, mov_func):
        pygame.sprite.Sprite.__init__(self)
        self.image=images[img_name]
        self.rect=self.image.get_rect()
        self.rect.center=tuple(pos)
        self.origin=Vector(pos)
        self.movement=mov_func
        self.frames=0
        self.damage=dmg
    def update(self):
        self.frames+=1
        self.rect.center=(self.origin+self.movement(self.frames)).to_tuple()
        if not PLAY_AREA.collidepoint(self.rect.midbottom):
            self.kill()
    def hurt(self, enemy):
        if self.alive():
            enemy.damage(self.damage)
            self.kill()

class Weapon:
    def __init__(self, ship, type=PTRN_DEF):
        self.ship=ship
        self.firing=False
        self.frames=0
        self.start_value,self.shots=type
        self.intervals=self.shots.keys()
    def update(self):
        if self.firing:
            for i in self.intervals:
                if not self.frames%i:
                    self.fire(i)
            self.frames+=1
    def on(self):
        self.firing=True
        self.frames=self.start_value
    def off(self):
        self.firing=False
    def fire(self, which):
        for (dmg,img,func) in self.shots[which]:
            shot_group.add(Shot(self.ship.rect.midtop, dmg, img, func))

class Level:
    def __init__(self, pattern):
        self.pattern=pattern
        self.frames=0
    def update(self):
        try:
            for (pos, life, img, func) in self.pattern[self.frames]:
                Enemy(pos, life, img, func)
        except KeyError:
            pass
        self.frames+=1
