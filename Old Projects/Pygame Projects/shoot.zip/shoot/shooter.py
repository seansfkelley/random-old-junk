#!/Library/Frameworks/Python.framework/Versions/Current/bin/python

from aux import *
from interface import *
from game_obj import *

pygame.init()

window=pygame.display.set_mode((XRES,YRES), DIS_FLAGS)
pygame.display.set_caption(NAME)
screen=pygame.display.get_surface()

background=pygame.Surface(screen.get_size()).convert()
background.fill((0,0,0))

load_all_images()
p1=DummyShip(P1_CONTROLS)
p2=DummyShip(P2_CONTROLS)

clock=pygame.time.Clock()

level_count=0

for i in xrange(len(LEVELS)):
    LEVELS[i]=Level(LEVELS[i])

while True:
    clock.tick(FRAMERATE)
    
    p_starting=handle_input(pygame.event.get(), p1, p2)
    if p_starting==1:
        p1=Ship(P1_START_POS, P1_CONTROLS, PTRN_LASER)
    elif p_starting==2:
        p2=Ship(P2_START_POS, P2_CONTROLS)
    
    LEVELS[level_count].update()
        
    shot_group.update()
    enemy_shot_group.update()
    enemy_group.update()
    ship_group.update()
    
    collisions=pygame.sprite.groupcollide(enemy_group, shot_group, False, False)
    for enemy in collisions:
        for s in collisions[enemy]:
            s.hurt(enemy)
    
    collisions=pygame.sprite.groupcollide(ship_group, enemy_group, False, False)
    for ship in collisions:
        if collisions[ship]:
            ship.die()
            collisions[ship][0].damage(DMG_COLLIDE)
    
    screen.blit(background, (0,0))
    
    shot_group.draw(screen)
    enemy_shot_group.draw(screen)
    enemy_group.draw(screen)
    ship_group.draw(screen)
    
    pygame.display.flip()
