import pygame, sys, os
from pygame.locals import *
from random import randint
from math import sin, cos, radians

#constants are below these class/function definitions

class Vector:
    def __init__(self, xy_or_x, y=None):
        if y is None:
            self.x,self.y=xy_or_x
        else:
            self.x=xy_or_x
            self.y=y
    def __add__(self, other):
        return Vector(self.x+other.x, self.y+other.y)
    def __sub__(self, other):
        return Vector(self.x-other.x, self.y-other.y)
    def __mul__(self, scalar):
        #doesn't work as int*vector...
        return Vector(self.x*scalar, self.y*scalar)
    def __neg__(self):
        return Vector(-self.x, -self.y)
    def __eq__(self, other):
        return self.x==other.x and self.y==other.y
    def __getitem__(self, which):
        if which==0:
            return self.x
        elif which==1:
            return self.y
        raise IndexError
    def __setitem__(self, key, value):
        if key==0:
            self.x=value
        elif key==1:
            self.y=value
        raise IndexError
    def __str__(self):
        return 'Vector<%f, %f>' % (self.x, self.y)
    def to_tuple(self):
        return (self.x, self.y)

def load_image(name, color_key=None, scaling=1):
    pathname=os.path.join(IMG_DIR,name+IMG_EXT)
    try:
        image=pygame.image.load(pathname)
    except pygame.error, msg:
        #print 'Error loading image %s' % name
        raise SystemExit, msg
    image=image.convert()
    if color_key:
        if color_key==-1:
            color_key=image.get_at((0,0))
        image.set_colorkey(color_key, RLEACCEL)
    if scaling!=1:
        image=scale(image, (int(image.get_size()[0]*scaling),
                            int(image.get_size()[1]*scaling)))
    return image

def load_all_images():
    for i in IMG_NAMES:
        images[i]=load_image(i)

def gcd(a, b):
    while b>0:
        a,b=b,a%b
    return a

def lcm(a, b):
    return a*b/gcd(a,b)

#begin constants----------------------------------------------------------------

NAME='Vertical Shooter!'

#visuals
XRES,YRES=600,800
DIS_FLAGS=0
IMG_NAMES=['ship', 'shot', 'enemy']

#gameplay
MOVE_SPEED_VERT,MOVE_SPEED_HORIZ=10,8
P1_CONTROLS=(K_w,K_s,K_a,K_d,K_LCTRL)
P2_CONTROLS=(K_UP,K_DOWN,K_LEFT,K_RIGHT,K_SPACE)
P1_START_POS=(XRES/4,YRES-100)
P2_START_POS=(3*XRES/4,YRES-100)
P1_START_BUTTON=K_6
P2_START_BUTTON=K_7
SHOT_SPEED_Y=30
SHOT_INT_DEF=8 #frames
DMG_DEF=1
ENEMY_LIFE=2
DMG_COLLIDE=2
SHOT_NAME_DEF='shot'

#movement functions
#parametric, t is the number of frames the unit has been alive
SF_DEF=         lambda t: Vector(0, -t*SHOT_SPEED_Y)
SF_FAST=        lambda t: Vector(0, -t*SHOT_SPEED_Y)
SF_LEFT=        lambda t: Vector(-24, -t*SHOT_SPEED_Y)
SF_RIGHT=       lambda t: Vector(24, -t*SHOT_SPEED_Y)
SF_ANGLE_LEFT=  lambda t: Vector(-6*t, -t*SHOT_SPEED_Y)
SF_ANGLE_RIGHT= lambda t: Vector(6*t, -t*SHOT_SPEED_Y)
SF_LEFT_SIN=    lambda t: Vector(32*sin(radians(24*t)), -t*SHOT_SPEED_Y)
SF_RIGHT_SIN=   lambda t: Vector(-32*sin(radians(24*t)), -t*SHOT_SPEED_Y)

EF_DEF=lambda t: Vector(0, t*MOVE_SPEED_VERT/2)

#firing lists
#trailing , for 1-tuple
PTRN_DEF=   (0,{SHOT_INT_DEF: ((DMG_DEF, SHOT_NAME_DEF, SF_DEF),)}) 
PTRN_LASER= (0,{2:            ((DMG_DEF, SHOT_NAME_DEF, SF_FAST),),
                12:           ((DMG_DEF, SHOT_NAME_DEF, SF_LEFT),
                               (DMG_DEF, SHOT_NAME_DEF, SF_RIGHT))})
PTRN_TRI=   (0,{SHOT_INT_DEF: ((DMG_DEF, SHOT_NAME_DEF, SF_DEF),
                               (DMG_DEF, SHOT_NAME_DEF, SF_ANGLE_LEFT),
                               (DMG_DEF, SHOT_NAME_DEF, SF_ANGLE_RIGHT))})
PTRN_WAVE=  (0,{SHOT_INT_DEF: ((DMG_DEF, SHOT_NAME_DEF, SF_LEFT_SIN),
                               (DMG_DEF, SHOT_NAME_DEF, SF_RIGHT_SIN))})

#levels
LEVELS=[]
LEVELS.append({60: (((0,0), 2, 'enemy', EF_DEF),
                    ((XRES,0), 2, 'enemy', EF_DEF))})

#internal/functional
PLAY_AREA=pygame.Rect(0,0,XRES,YRES)
FRAMERATE=30
IMG_EXT='.png'
IMG_DIR='images'

#aliases
scale=pygame.transform.smoothscale

#globals
images={}
ship_group=pygame.sprite.Group()
shot_group=pygame.sprite.Group()
enemy_group=pygame.sprite.Group()
enemy_shot_group=pygame.sprite.Group()
