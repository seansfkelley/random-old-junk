from aux import *

def handle_input(events, p1, p2):
    player_start=0
    for e in events:
        if e.type==KEYDOWN and not p1.keydown(e.key) and not p2.keydown(e.key):
            if e.key==P1_START_BUTTON:
                player_start=1
            elif e.key==P2_START_BUTTON:
                player_start=2
        elif e.type==KEYUP and not p1.keyup(e.key) and not p2.keyup(e.key):
            pass
        elif e.type==QUIT:
            sys.exit(0)
    return player_start
