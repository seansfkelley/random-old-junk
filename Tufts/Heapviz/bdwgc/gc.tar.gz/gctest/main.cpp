#include "global.h"
#include "nodes.h"
#include "dummy.h"
#include <set>

using namespace std;

int main(){
  /*
  Node *list = NULL;
  for (int i = 0; i < 20; ++i){
    list = ll_prepend(list, i);
  }
  // ll_print(list);
  */
  set<Dummy, less<Dummy>, gc_allocator<Dummy> > s;

  for (int i = 0; i < 50; ++i){
    s.insert(Dummy(i));
  }
  
  dump_heap();  
};
