#ifndef MEMORY_H
#define MEMORY_H

#include "global.h"

void *MALLOC(size_t);
void dump_heap();

#endif
