#ifndef GLOBAL_H
#define GLOBAL_H

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include "memory.h"
#include "gc/gc.h"
#include "gc/gc_cpp.h"
#include "gc/gc_allocator.h"

#endif
