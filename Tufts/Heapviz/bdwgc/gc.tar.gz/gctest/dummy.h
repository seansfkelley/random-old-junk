#ifndef DUMMY_H
#define DUMMY_H

class Dummy{
public:
  int datum;
  Dummy() : datum(0) {}
  Dummy(int d) : datum(d) {}
  bool operator<(Dummy o) const {datum < o.datum;}
};

#endif
