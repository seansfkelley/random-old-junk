#ifndef LL_H
#define LL_H

#include "global.h"

typedef struct Node{
  int datum;
  struct Node *next;
} Node;

Node *ll_remove(Node*, int);

Node *ll_prepend(Node*, int);

int ll_length(Node*);

void ll_print(Node*);

#endif
