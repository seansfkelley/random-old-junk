#include "nodes.h"

Node *ll_prepend(Node *list, int i){
  Node *n = (Node*)MALLOC(sizeof(Node));
  n->datum = i;
  n->next = list;
  return n;
}

Node *ll_remove(Node *list, int i){
  Node *n = list, *prev = NULL;
  while (n && n->datum != i){
    prev = n;
    n = n->next;
  }
  if (n){
    if (prev)
      prev->next = n->next;
    else
      list = list->next;
  }
  return list;
}

int ll_length(Node *list){
  int len = 0;
  for (Node *n = list; n; n = n->next)
    len++;
  return len;
}

void ll_print(Node *list){
  printf("list length = %d\n", ll_length(list));
  for (Node *n = list; n; n = n->next)
    printf("0x%x: %d\n", n, n->datum);
}

