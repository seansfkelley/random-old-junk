cd ../gc-7.2alpha6
make && make install
