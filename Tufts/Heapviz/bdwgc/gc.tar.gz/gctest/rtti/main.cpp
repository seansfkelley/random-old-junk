#include <iostream>
#include <typeinfo>

#include "global.h"
#include "classes.h"

using namespace std;

void store_and_retrieve(int i, Base *b){
  b->set(i);
  cout << "in: " << i << " -> out: " << b->get() << endl;
}

int main(){
  Base *b;
  b = new PlusOne();
  store_and_retrieve(10, b);
  b = new MinusOne();
  store_and_retrieve(10, b);
  b = new PlusTwo();
  store_and_retrieve(10, b);

  dump_heap();
}
