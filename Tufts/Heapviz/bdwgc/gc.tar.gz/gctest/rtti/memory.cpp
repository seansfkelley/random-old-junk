#include "memory.h"

void *MALLOC(size_t bytes){
  return GC_malloc(bytes);
}

void dump_heap(){
  fprintf(stderr, "dumping heap\n"); 
  GC_gcollect();
  fprintf(stderr, "end heap dump\n");
}
